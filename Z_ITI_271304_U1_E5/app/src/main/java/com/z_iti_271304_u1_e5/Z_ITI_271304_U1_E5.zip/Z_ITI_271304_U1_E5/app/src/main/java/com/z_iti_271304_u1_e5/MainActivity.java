package com.z_iti_271304_u1_e5;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TabHost;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Importante: Esto va antes de instanciar controles dentro de cada pestaña

        // Agregar las pestañas---
        Resources res = getResources();
        TabHost tabHost = (TabHost) findViewById(R.id.tabhost);
        tabHost.setup();

        TabHost.TabSpec spec1 = tabHost.newTabSpec("");
        spec1.setContent(R.id.tab1);
        spec1.setIndicator("2 Variables");

        TabHost.TabSpec spec2 = tabHost.newTabSpec("");
        spec2.setContent(R.id.tab2);
        spec2.setIndicator("3 Variables");

        TabHost.TabSpec spec3 = tabHost.newTabSpec("");
        spec3.setContent(R.id.tab3);
        spec3.setIndicator("4 Variables");
        //spec3.setIndicator("",getResources().getDrawable(R.mipmap.ic_launcher));

        TabHost.TabSpec spec4 = tabHost.newTabSpec("");
        spec4.setContent(R.id.tab4);
        spec4.setIndicator("5 VAriables");

        tabHost.addTab(spec1);
        tabHost.addTab(spec2);
        tabHost.addTab(spec3);
        tabHost.addTab(spec4);

        RadioGroup radioGroup = findViewById(R.id.radioGroup_2_0);
        Button calcularButton = findViewById(R.id.btnCalcular0);

        calcularButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener el ID del RadioButton seleccionado
                int selectedId = radioGroup.getCheckedRadioButtonId();
                Toast.makeText(getApplicationContext(), "Seleccionado: " + selectedId, Toast.LENGTH_SHORT).show();

                // Si se seleccionó un RadioButton
                if (selectedId != -1) {
                    // Encontrar el RadioButton por ID
                    RadioButton selectedRadioButton = findViewById(selectedId);

                    // Obtener el texto del RadioButton seleccionado
                    String selectedValue = selectedRadioButton.getText().toString();

                    // Mostrar el valor seleccionado (puedes hacer cualquier cosa con este valor)
                    Toast.makeText(getApplicationContext(), "Seleccionado: " + selectedValue, Toast.LENGTH_SHORT).show();
                } else {
                    // En caso de que no se haya seleccionado ningún RadioButton
                    Toast.makeText(getApplicationContext(), "No se seleccionó ninguna opción", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
